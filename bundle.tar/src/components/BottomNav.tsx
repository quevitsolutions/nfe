'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, LayoutDashboard, Presentation, BookOpen, MessageCircle } from 'lucide-react';

const mobileNavItems = [
  { name: 'Home', href: '/', icon: Home },
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Slides', href: '/presentation', icon: Presentation },
  { name: 'Docs', href: '/reference/protocol-economics', icon: BookOpen },
  { name: 'Help', href: '/help', icon: MessageCircle },
];

export default function BottomNav() {
  const pathname = usePathname();

  // Hide on homepage — homepage has its own layout
  if (pathname === '/') return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-black/5 flex items-center justify-around h-20 px-4 z-50 lg:hidden shadow-2xl safe-area-pb">
      {mobileNavItems.map((item) => {
        const isActive = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`flex flex-col items-center gap-1.5 transition-all text-[10px] font-black uppercase tracking-tighter ${
              isActive ? 'text-[#ed1b24]' : 'text-slate-400 opacity-60'
            }`}
          >
            <item.icon className={`w-6 h-6 ${isActive ? 'scale-110 drop-shadow-sm' : ''}`} />
            <span>{item.name}</span>
            {isActive && <div className="absolute -bottom-1 w-12 h-1 bg-[#ed1b24] rounded-full" />}
          </Link>
        );
      })}
    </nav>
  );
}
