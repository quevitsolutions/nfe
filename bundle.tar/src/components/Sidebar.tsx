'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Presentation, BookOpen, LayoutDashboard, Settings, User } from 'lucide-react';

const navItems = [
  { name: 'Home', href: '/', icon: Home },
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Presentation', href: '/presentation', icon: Presentation },
  { name: 'Protocol', href: '/reference/protocol-economics', icon: BookOpen },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();

  // Hide on homepage — homepage has its own floating navbar
  if (pathname === '/') return null;

  return (
    <aside className="fixed left-0 top-0 h-screen w-[var(--sidebar-width)] bg-white border-r border-black/5 z-50 hidden lg:flex flex-col">
      {/* Profile Section */}
      <div className="p-8 border-b border-black/5">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-[#fcf3eb] flex items-center justify-center border border-[#ed1b24]/10">
            <User className="w-6 h-6 text-[#ed1b24]" />
          </div>
          <div>
            <h3 className="font-black text-sm uppercase tracking-tight">Vipechan</h3>
            <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase">8630115027</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-6 space-y-2">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-2xl transition-all font-bold text-sm tracking-tight ${
                isActive
                  ? 'bg-[#ed1b24] text-white shadow-lg shadow-[#ed1b24]/20'
                  : 'text-slate-500 hover:bg-[#fcf3eb] hover:text-[#ed1b24]'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.name}
            </Link>
          );
        })}
      </nav>

      {/* Footer Branding */}
      <div className="p-8 border-t border-black/5 opacity-40">
        <p className="text-[10px] font-black uppercase tracking-[0.3em] italic text-slate-400">
          AIPCORE PROTOCOL v1.0
        </p>
      </div>
    </aside>
  );
}
