'use client';

import { useAccount } from 'wagmi';
import { 
    useUserIdByAddress, 
    useClaim, 
    useIncomeBreakdown, 
    usePoolViewHelper, 
    useUserInfo, 
    usePoolRequirements 
} from '@/lib/hooks/useContract';
import { formatBNB } from '@/lib/contract';
import { 
    Gift, 
    Wallet, 
    Award, 
    ArrowUpRight, 
    Ban, 
    TrendingUp, 
    Layers, 
    Network, 
    Activity, 
    Cpu,
    CheckCircle2,
    Lock,
    Sparkles,
    ChevronRight
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { ManualSyncButton } from '@/components/ManualSyncButton';
import { useCurrency } from '@/lib/CurrencyContext';

export default function RewardsPage() {
    const { address, isConnected } = useAccount();
    const [isMounted, setIsMounted] = useState(false);
    const { formatConverted, selectedCurrency } = useCurrency();

    const { data: userData } = useUserIdByAddress(address);
    const userId = userData ? Number(userData) : 0;

    const { data: poolView, refetch: refetchPoolView } = usePoolViewHelper(userId);
    const { data: userInfo, refetch: refetchUserInfo } = useUserInfo(userId);
    const { data: coreIncomeData, refetch: refetchCoreIncome } = useIncomeBreakdown(userId);
    const { data: poolReqs } = usePoolRequirements();

    const { claim, isPending: isClaimPending, isConfirming: isClaimConfirming, isSuccess: isClaimSuccess, error: claimError } = useClaim();

    useEffect(() => {
        setIsMounted(true);
    }, []);

    useEffect(() => {
        if (isClaimSuccess && userId > 0) {
            refetchPoolView();
            refetchUserInfo();
            refetchCoreIncome();
        }
    }, [isClaimSuccess, userId, refetchPoolView, refetchUserInfo, refetchCoreIncome]);

    if (!isMounted || !isConnected) return null;

    const currentPoolId = poolView ? Number(poolView[0]) : 0;
    const poolName = poolView ? String(poolView[1]) : 'None';
    const claimableBNB = poolView ? poolView[2] as bigint : BigInt(0);
    const lifetimeClaimed = poolView ? poolView[4] as bigint : BigInt(0);
    const capRemaining = poolView ? poolView[5] as bigint : BigInt(0);
    const lifetimeCap = poolView ? poolView[6] as bigint : BigInt(0);
    const totalDeposited = poolView ? poolView[7] as bigint : BigInt(0);
    const nfeLayer = poolView ? Number(poolView[8]) : 0;
    const isQualifiedForNext = poolView ? Boolean(poolView[9]) : false;
    const mq = poolView ? poolView[11] as bigint[] : undefined;

    const isCapReached = lifetimeClaimed >= lifetimeCap && lifetimeCap > BigInt(0);
    
    let missingRequirements = '';
    if (mq && mq.length === 3) {
        const parts = [];
        if (Number(mq[0]) > 0) parts.push(`${mq[0]} layers`);
        if (Number(mq[1]) > 0) parts.push(`${mq[1]} directs`);
        if (Number(mq[2]) > 0) parts.push(`${mq[2]} team`);
        missingRequirements = parts.join(', ');
    }

    const formatPrice = (val: bigint) => (Number(val) / 1e18).toFixed(4);

    return (
        <div className="space-y-8 pb-12">
            {/* 1. Main Reward Banner */}
            <div className={`relative overflow-hidden bg-slate-900/60 backdrop-blur-xl rounded-[2.5rem] border border-white/5 shadow-2xl p-10 lg:p-12 mb-8 group`}>
                <div className="absolute top-0 right-0 -mt-8 -mr-8 opacity-[0.05] text-brand-green group-hover:scale-110 transition-transform duration-700">
                    <Gift className="w-80 h-80" />
                </div>
                
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-10">
                    <div className="space-y-6">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-brand-green/10 rounded-2xl flex items-center justify-center border border-white/5">
                                <Award className="w-6 h-6 text-brand-green" />
                            </div>
                            <div className="flex flex-col">
                                <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] italic">Neural Status</span>
                                <span className="text-xl font-black text-sharp-green italic">{currentPoolId === 0 ? 'NEURAL SYNC PENDING' : `${poolName} POOL ACTIVE`}</span>
                            </div>
                        </div>
                        
                        <div className="space-y-1">
                            {currentPoolId === 0 ? (
                                <div className="space-y-4">
                                      <div className="text-4xl lg:text-5xl font-black text-slate-500 tracking-tighter uppercase italic">Offline Yield</div>
                                      {mq && Number(mq[0]) === 0 && Number(mq[1]) === 0 && Number(mq[2]) === 0 ? (
                                          <div className="bg-brand-green/10 border border-brand-green/20 p-6 rounded-[2rem] space-y-2 animate-in fade-in slide-in-from-bottom-4 shadow-sm backdrop-blur-md">
                                              <div className="text-2xl font-black text-brand-green italic">✨ Qualified for Bronze!</div>
                                              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-relaxed italic">Your node has met all neural requirements.<br/>Click manual sync below if registration is pending.</p>
                                              <div className="animate-bounce pt-2">
                                                  <ManualSyncButton nodeId={userId} />
                                              </div>
                                          </div>
                                     ) : (
                                         <p className="text-sm font-bold text-slate-500 uppercase tracking-widest max-w-[300px]">Unlock global distribution by qualifying for the Bronze Pool.</p>
                                     )}
                                </div>
                            ) : (
                                <div className="space-y-6">
                                    <div className="flex items-baseline gap-4">
                                        <span className="text-7xl lg:text-9xl font-black text-variable-amber tracking-tighter italic">
                                            {formatBNB(claimableBNB)}
                                        </span>
                                        <span className="text-2xl lg:text-4xl font-black text-slate-500 uppercase tracking-tighter italic font-sans leading-none">BNB</span>
                                    </div>
                                    <p className="text-xl font-black text-slate-300 italic">
                                        ≈ <span className="text-variable-amber">{formatConverted(Number(claimableBNB) / 1e18)}</span>
                                        <span className="text-[10px] text-brand-red ml-2 uppercase tracking-widest italic">{selectedCurrency.code} Pool Revenue</span>
                                    </p>
                                    <div className="flex flex-wrap gap-4">
                                        <button 
                                            onClick={() => claim()}
                                            disabled={isClaimPending || isClaimConfirming || Number(claimableBNB) === 0 || isCapReached}
                                            className={`px-10 py-5 rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl transition-all flex items-center gap-3 italic ${
                                                Number(claimableBNB) > 0 && !isCapReached
                                                ? 'bg-brand-red text-white hover:scale-105 active:scale-95'
                                                : 'bg-white/5 text-slate-600 border border-white/5 cursor-not-allowed'
                                            }`}
                                        >
                                            <Gift className="w-5 h-5" />
                                            {isClaimPending || isClaimConfirming ? 'Securing...' : isCapReached ? 'CAP REACHED' : 'Sync Yield Now Â»'}
                                        </button>
                                        
                                        {isQualifiedForNext && (
                                            <div className="bg-brand-green/10 border border-brand-green/20 p-5 rounded-[2rem] flex items-center gap-4 animate-in zoom-in-95 shadow-sm backdrop-blur-md">
                                                <Sparkles className="w-5 h-5 text-brand-green" />
                                                <div className="flex flex-col">
                                                    <span className="text-[10px] font-black text-brand-green uppercase tracking-widest leading-none mb-2 italic">Neural Expansion Qualified</span>
                                                    <ManualSyncButton nodeId={userId} isQualifiedForNext={true} />
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="flex flex-col gap-4 w-full md:w-auto min-w-[280px]">
                        <div className="bg-white/5 backdrop-blur-xl rounded-[2.5rem] p-8 border border-white/5 flex flex-col items-center justify-center text-center space-y-4 shadow-sm">
                             <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest italic">Neural Performance</div>
                             <div className="flex gap-4">
                                 <div className="flex flex-col items-center p-4 bg-slate-900/60 rounded-3xl shadow-sm min-w-[100px] border border-white/5">
                                     <span className="text-xs font-black text-variable-amber tracking-tighter italic">{formatBNB(lifetimeClaimed)}</span>
                                     <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest mt-1 italic">Realized</span>
                                 </div>
                                 <div className="flex flex-col items-center p-4 bg-slate-900/60 rounded-3xl shadow-sm min-w-[100px] border border-white/5">
                                      <span className="text-xs font-black text-brand-red tracking-tighter italic">{formatBNB(capRemaining)}</span>
                                      <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest mt-1 italic">Available</span>
                                 </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* 2. Pool Status & Tiers (Vi Style Grid) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {[
                    { id: 1, name: 'Bronze', cardClass: 'bg-slate-900/60 backdrop-blur-xl border border-white/5 hover:border-brand-green/20 shadow-xl rounded-[2.5rem]', icon: Award, active: currentPoolId >= 1 },
                    { id: 2, name: 'Silver', cardClass: 'card-green', icon: Sparkles, active: currentPoolId >= 2 },
                    { id: 3, name: 'Gold',   cardClass: 'card-red',   icon: Award, active: currentPoolId >= 3 },
                ].map((pool) => (
                    <div key={pool.id} className={`relative overflow-hidden ${pool.cardClass} p-10 transition-all group ${
                        pool.id !== currentPoolId && pool.id <= 3 ? 'opacity-60 grayscale-[0.0]' : ''
                    }`}>
                        <div className={`absolute top-4 right-4 text-brand-green/10 group-hover:scale-125 transition-transform`}>
                            <pool.icon className="w-16 h-16" />
                        </div>
                        
                        <div className="relative z-10 flex flex-col items-center text-center space-y-6">
                            <div className={`w-20 h-20 rounded-[2rem] flex items-center justify-center border transition-all ${
                                pool.id <= currentPoolId 
                                ? 'bg-brand-green text-slate-950 border-brand-green shadow-xl scale-110' 
                                : 'bg-white/5 border-white/10 text-slate-600 shadow-inner'
                            }`}>
                                {pool.id <= currentPoolId ? <CheckCircle2 className="w-10 h-10" /> : <Lock className="w-10 h-10" />}
                            </div>
                            
                            <div>
                                <h4 className="text-2xl font-black text-sharp-green tracking-tight leading-none mb-2 italic">{pool.name} Matrix</h4>
                                <p className={`text-[10px] font-black uppercase tracking-widest italic ${pool.id <= currentPoolId ? (pool.id === 3 ? 'text-brand-red' : 'text-brand-green') : 'text-slate-500'}`}>
                                    {pool.id < currentPoolId ? 'Neural Stream Verified' : pool.id === currentPoolId ? 'Primary Data Source' : 'Neural Path Locked'}
                                </p>
                            </div>

                            {pool.id > currentPoolId && (
                                <div className="w-full pt-4 space-y-3">
                                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                                        <div className="h-full bg-brand-green/40 rounded-full w-1/3" />
                                    </div>
                                    <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest italic leading-none">Authorization Pending</p>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>

            {/* 3. Global Stats */}
            <div className="bg-slate-900/60 backdrop-blur-xl rounded-[2.5rem] p-8 lg:p-10 border border-white/5 shadow-2xl grid grid-cols-2 md:grid-cols-4 gap-8">
                <div className="space-y-2">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none italic">Total Yield Flow</p>
                    <p className="text-2xl font-black text-variable-amber tracking-tighter italic">{formatBNB(totalDeposited)} <span className="text-[10px] font-sans opacity-50">BNB</span></p>
                </div>
                <div className="space-y-2">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none italic">Capacity</p>
                    <p className="text-2xl font-black text-slate-200 tracking-tighter italic">8,192 <span className="text-[10px] font-sans opacity-50">Nodes</span></p>
                </div>
                <div className="space-y-2">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none italic">Efficiency</p>
                    <p className="text-2xl font-black text-brand-green tracking-tighter italic">100.0% <span className="text-[10px] font-sans opacity-50">UPTIME</span></p>
                </div>
                <div className="space-y-2">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none italic">Status</p>
                    <p className="text-2xl font-black text-brand-red tracking-tighter italic">SYNCED</p>
                </div>
            </div>
            
            {/* Error Handlers */}
            {claimError && (
                <div className="bg-brand-red/10 border border-brand-red/20 p-6 rounded-[2rem] text-brand-red font-bold text-xs uppercase tracking-widest flex items-center justify-between backdrop-blur-md">
                    <div className="flex items-center gap-4">
                        <Activity className="w-5 h-5" />
                        <span>Execution Rejected: {(claimError as any).shortMessage || claimError.message}</span>
                    </div>
                    <button onClick={() => window.location.reload()} className="hover:underline">Retry Connection</button>
                </div>
            )}

            {isClaimSuccess && (
                <div className="bg-brand-green/10 border border-brand-green/20 p-6 rounded-[2rem] text-brand-green font-black text-[10px] uppercase tracking-widest flex items-center gap-4 animate-in fade-in italic backdrop-blur-md">
                    <CheckCircle2 className="w-6 h-6" />
                    <span>Neural Yield Successfully Synchronized with Node Vault.</span>
                </div>
            )}
        </div>
    );
}




