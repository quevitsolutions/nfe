'use client';

import { useState } from 'react';
import { useAccount } from 'wagmi';
import { ArrowUpCircle, Check, Loader2, Layers, ShieldCheck, Zap, TrendingUp, Info, Network } from 'lucide-react';
import { useUpgrade, useLevelCosts, useContractConfig, useUserInfo, useUserIdByAddress } from '@/lib/hooks/useContract';
import { formatBNB, formatCurrency, LEVEL_COSTS_USD } from '@/lib/contract';
import { useCurrency } from '@/lib/CurrencyContext';

export default function UpgradePage() {
    const { isConnected, address } = useAccount();
    const [selectedLevel, setSelectedLevel] = useState<number>(0);

    const { data: userData } = useUserIdByAddress(address);
    const userId = userData ? Number(userData) : 0;

    const { data: userInfo } = useUserInfo(userId);
    const { data: levelCosts } = useLevelCosts();
    const { data: config } = useContractConfig();
    const { upgrade, isPending, isConfirming, isSuccess, hash } = useUpgrade();
    const { formatFromUSD, selectedCurrency } = useCurrency();

    const currentLevel = userInfo ? Number((userInfo as any)[3]) : 0;
    
    if (selectedLevel === 0 && currentLevel > 0) {
        setSelectedLevel(Math.min(18, currentLevel + 1));
    }

    const isGenesisUser = userId === 36999;
    const upgradeCost = isGenesisUser || !levelCosts
        ? BigInt(0)
        : levelCosts.slice(currentLevel, selectedLevel).reduce((acc, cost) => acc + (cost || BigInt(0)), BigInt(0));

    const exactUsdCost = LEVEL_COSTS_USD
        .slice(currentLevel, selectedLevel)
        .reduce((a, b) => a + b, 0);

    const handleUpgrade = async () => {
        if (!isConnected || selectedLevel <= currentLevel) return;
        try {
            await upgrade(userId, selectedLevel, upgradeCost);
        } catch (error) {
            console.error('Upgrade failed:', error);
        }
    };

    return (
        <div className="space-y-8 pb-12">
            {/* 1. Header Overview Banner */}
            <div className="vi-card p-10 lg:p-12 mb-8 relative overflow-hidden group border-[#ed1b24]/5">
                <div className="absolute top-0 right-0 -mt-8 -mr-8 opacity-[0.03] text-[#ed1b24] group-hover:scale-110 transition-transform duration-700">
                    <Layers className="w-64 h-64" />
                </div>
                
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-10">
                    <div className="space-y-6">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-[#ed1b24]/5 rounded-2xl flex items-center justify-center border border-[#ed1b24]/10">
                                <Zap className="w-6 h-6 text-[#ed1b24]" />
                            </div>
                            <span className="text-sm font-black text-slate-400 uppercase tracking-[0.2em] italic">Neural Scaling</span>
                        </div>
                        
                        <div className="space-y-1">
                            <div className="flex items-baseline gap-4 text-center md:text-left">
                                <span className="text-6xl lg:text-8xl font-black text-[#ed1b24] tracking-tighter italic">
                                    Tier {currentLevel}
                                </span>
                                <span className="text-2xl lg:text-3xl font-black text-slate-200 uppercase tracking-tighter italic font-sans leading-none">Access</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-[#fcf3eb] rounded-[2.5rem] p-8 border border-[#ed1b24]/10 text-center space-y-4 min-w-[300px] shadow-sm">
                         <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none italic">Neural Authority Matrix</div>
                         <div className="flex items-center justify-center gap-3">
                             <ShieldCheck className="w-8 h-8 text-[#ed1b24]" />
                             <span className="text-3xl font-black text-slate-800 tracking-tighter italic">Verified Node</span>
                         </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* 2. Tier Selector Panel */}
                <div className="vi-card p-10 space-y-8 border-[#ed1b24]/5">
                    <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-[#fcf3eb] rounded-2xl flex items-center justify-center border border-[#ed1b24]/10">
                            <Layers className="w-5 h-5 text-[#ed1b24]" />
                        </div>
                        <h2 className="text-2xl font-black text-slate-800 tracking-tight uppercase italic">Neural Tiers</h2>
                    </div>

                    <div className="grid grid-cols-6 gap-3">
                        {Array.from({ length: 18 }, (_, i) => i + 1).map((level) => (
                            <button
                                key={level}
                                onClick={() => setSelectedLevel(level)}
                                disabled={level <= currentLevel}
                                className={`
                                    h-14 rounded-2xl font-black text-xs transition-all border
                                    ${selectedLevel === level
                                        ? 'bg-[#ed1b24] text-white border-[#ed1b24] shadow-xl scale-110 z-10 italic'
                                        : level <= currentLevel
                                            ? 'bg-[#fcf3eb] border-[#ed1b24]/10 text-slate-300 cursor-not-allowed opacity-50'
                                            : 'bg-white border-black/5 text-slate-400 hover:border-[#ed1b24]/30 hover:text-[#ed1b24]'
                                    }
                                `}
                            >
                                {level < 10 ? `0${level}` : level}
                            </button>
                        ))}
                    </div>

                    <div className="bg-[#fcf3eb] border border-[#ed1b24]/10 rounded-[2rem] p-8 space-y-4 shadow-sm">
                        <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                            <span className="text-slate-500 italic">Target Scaling:</span>
                            <span className="text-[#ed1b24] italic">Tier {selectedLevel}</span>
                        </div>
                        <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                            <span className="text-slate-500 italic">Authorization Steps:</span>
                            <span className="text-slate-800 italic">{Math.max(0, selectedLevel - currentLevel)} Layers</span>
                        </div>
                        <div className="pt-2 border-t border-[#ed1b24]/10 flex justify-between items-center">
                            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest italic">Protocol Cost:</span>
                            <span className="text-2xl font-black text-[#ed1b24] tracking-tighter italic">
                                {formatFromUSD(exactUsdCost)}
                            </span>
                        </div>
                    </div>
                </div>

                {/* 3. Authentication Panel */}
                <div className="flex flex-col">
                <div className="vi-card p-10 flex-1 relative overflow-hidden group border-[#ed1b24]/5">
                    <div className="absolute top-0 right-0 -mt-6 -mr-6 opacity-[0.05] text-[#ed1b24] group-hover:rotate-12 transition-transform duration-500">
                        <ArrowUpCircle className="w-48 h-48" />
                    </div>
                    
                    <h2 className="text-2xl font-black text-slate-800 tracking-tight uppercase mb-8 italic">Authorization</h2>

                    {isSuccess ? (
                        <div className="bg-[#fcf3eb] border border-[#ed1b24]/10 rounded-[2.5rem] p-10 text-center animate-in zoom-in-95">
                            <div className="w-20 h-20 bg-[#ed1b24] shadow-xl rounded-3xl flex items-center justify-center mx-auto mb-6">
                                <Check className="w-12 h-12 text-white" />
                            </div>
                            <h3 className="text-2xl font-black text-[#ed1b24] mb-2 uppercase tracking-tight italic">Access Granted</h3>
                            <p className="text-xs font-bold text-slate-600 uppercase tracking-widest mb-6 italic">Your Node is now Synchronized in Tier {selectedLevel}</p>
                            {hash && (
                                <a
                                    href={`${(config as any)?.blockExplorers?.default?.url}/tx/${hash}`}
                                    target="_blank" rel="noopener noreferrer"
                                    className="px-8 py-3 bg-white border border-[#ed1b24]/10 text-[#ed1b24] rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-[#fcf3eb] transition-all inline-block italic"
                                >
                                    View Tx Ledger »
                                </a>
                            )}
                        </div>
                    ) : (
                        <div className="space-y-8">
                            <div className="bg-[#fcf3eb] border border-[#ed1b24]/10 rounded-[2rem] p-8 text-center space-y-4 shadow-sm">
                                <div className="text-5xl lg:text-6xl font-black text-[#ed1b24] tracking-tighter italic">
                                    {formatBNB(upgradeCost)} <span className="text-xl text-slate-300 uppercase italic font-sans">BNB</span>
                                </div>
                                <div className="text-[10px] font-black text-slate-400 bg-white px-6 py-2 rounded-full uppercase tracking-widest inline-block border border-[#ed1b24]/10 shadow-sm italic">
                                    Market Value: {formatFromUSD(exactUsdCost)}
                                </div>
                            </div>

                            <button
                                onClick={handleUpgrade}
                                disabled={!isConnected || selectedLevel <= currentLevel || isPending || isConfirming}
                                className="w-full relative overflow-hidden bg-[#ed1b24] text-white py-6 rounded-[2rem] font-black tracking-widest text-sm uppercase shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-30 disabled:grayscale disabled:hover:scale-100 flex items-center justify-center gap-3 group italic"
                            >
                                {isPending || isConfirming ? (
                                    <>
                                        <Loader2 className="animate-spin w-6 h-6" />
                                        Authenticating Node...
                                    </>
                                ) : (
                                    <>
                                        <ArrowUpCircle className="w-6 h-6 group-hover:animate-bounce" />
                                        Authorize Neural Expansion
                                    </>
                                )}
                            </button>

                                 <div className="grid grid-cols-2 gap-3">
                                <div className="bg-[#fcf3eb] p-4 rounded-2xl flex items-center gap-3 border border-[#ed1b24]/10 shadow-sm">
                                    <TrendingUp className="w-4 h-4 text-[#ed1b24]" />
                                    <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest italic">Performance Boost</span>
                                </div>
                                <div className="bg-[#fcf3eb] p-4 rounded-2xl flex items-center gap-3 border border-[#ed1b24]/10 shadow-sm">
                                    <Network className="w-4 h-4 text-[#ed1b24]" />
                                    <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest italic">Network Depth</span>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
                </div>
            </div>

            {/* 4. Directory Grid */}
            <div className="vi-card p-10 space-y-10 border-[#ed1b24]/5">
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-[#fcf3eb] border border-[#ed1b24]/10 rounded-2xl flex items-center justify-center shadow-sm">
                        <Info className="w-5 h-5 text-[#ed1b24]" />
                    </div>
                    <h2 className="text-2xl font-black text-slate-800 tracking-tight uppercase leading-none italic">Neural Directory</h2>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    {LEVEL_COSTS_USD.map((cost, index) => (
                        <div
                            key={index}
                            className={`rounded-3xl p-6 border transition-all ${index < currentLevel
                                ? 'bg-[#fcf3eb] border-[#ed1b24]/20 shadow-sm opacity-60'
                                : index < selectedLevel
                                    ? 'bg-white border-[#ed1b24] shadow-2xl scale-105 z-10'
                                    : 'bg-transparent border-black/5 opacity-40'
                                }`}
                        >
                            <div className={`text-[9px] font-black uppercase tracking-widest mb-1 italic ${index < currentLevel ? 'text-[#ed1b24]' : index < selectedLevel ? 'text-[#ed1b24]' : 'text-slate-400'}`}>Layer {index + 1}</div>
                            <div className={`text-xl font-black italic ${index < currentLevel ? 'text-slate-400' : index < selectedLevel ? 'text-[#ed1b24]' : 'text-slate-300'}`}>{formatFromUSD(cost)}</div>
                            <div className="text-[9px] font-black text-slate-400 mt-1 uppercase tracking-tighter">
                                {levelCosts ? formatBNB(levelCosts[index]) : '---'} <span className="font-sans opacity-50">BNB</span>
                            </div>
                            {index < currentLevel && (
                                <div className="text-[8px] text-[#ed1b24] font-black uppercase tracking-widest mt-4 bg-white w-fit px-2 py-1 rounded-full flex items-center gap-1 border border-[#ed1b24]/10 italic">
                                    <Check className="w-3 h-3" /> Activated
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}





