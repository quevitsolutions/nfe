﻿'use client';

import { ReactNode, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import {
    LayoutDashboard,
    TrendingUp,
    Users,
    GitBranch,
    Network,
    ArrowUpCircle,
    Megaphone,
    Gift,
} from 'lucide-react';

import { useState } from 'react';
import { CurrencySelector } from '@/components/CurrencySelector';
import { useCurrency } from '@/lib/CurrencyContext';
import { useBnbPrice } from '@/lib/hooks/useContract';

const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Income History', path: '/dashboard/income', icon: TrendingUp },
    { name: 'Node Network', path: '/dashboard/team', icon: Users },
    { name: 'Sponsorship Tree', path: '/dashboard/referral-tree', icon: GitBranch },
    { name: 'Node Matrix', path: '/dashboard/matrix-tree', icon: Network },
    { name: 'Node Layers', path: '/dashboard/upgrade', icon: ArrowUpCircle },
    { name: 'Reward Pools', path: '/dashboard/rewards', icon: Gift },
    { name: 'Promotion', path: '/dashboard/promotion', icon: Megaphone },
];

/** Inner component so we can use hooks that depend on CurrencyContext */
function DashboardLayoutInner({ children, pathname }: { children: ReactNode; pathname: string }) {
    const { setBnbPriceUSD } = useCurrency();
    const { data: currentBnbPrice } = useBnbPrice();

    // Sync live BNB price to CurrencyContext so all pages share
    useEffect(() => {
        if (currentBnbPrice) {
            setBnbPriceUSD(Number(currentBnbPrice) / 1e8);
        }
    }, [currentBnbPrice, setBnbPriceUSD]);

    return (
        <div className="min-h-screen bg-background text-slate-100 pb-20 lg:pb-0 font-sans font-black uppercase tracking-tighter transition-colors duration-500">
            {/* Desktop Sidebar (Dark Glass Style) */}
            <aside className="hidden lg:flex fixed inset-y-0 left-0 w-72 flex-col p-6 z-40">
                <div className="bg-slate-900/40 backdrop-blur-2xl rounded-[2.5rem] shadow-2xl border border-white/5 flex flex-col h-full overflow-hidden">
                    <div className="p-8 border-b border-white/5">
                        <Link href="/" className="block text-center group">
                            <img src="/aipcore-logo.svg" alt="AIPCORE" className="h-10 w-auto mx-auto transition-all group-hover:scale-105 filter brightness-0 invert" />
                        </Link>
                    </div>

                    <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
                        {navItems.map((item) => {
                            const Icon = item.icon;
                            const isActive = pathname === item.path;

                            return (
                                <Link
                                    key={item.path}
                                    href={item.path}
                                    className={`
                                        flex items-center gap-4 px-6 py-4 rounded-[1.5rem] transition-all duration-300 group
                                        ${isActive
                                            ? 'bg-brand-blue text-white shadow-[0_0_25px_rgba(0,136,255,0.4)]'
                                            : 'text-slate-500 hover:bg-white/5 hover:text-brand-blue'
                                        }
                                    `}
                                >
                                    <Icon className={`w-5 h-5 transition-transform group-hover:scale-110`} />
                                    <span className="font-bold tracking-tight">{item.name}</span>
                                </Link>
                            );
                        })}
                    </nav>

                        <div className="p-6 mt-auto">
                            <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                                <p className="text-[10px] uppercase tracking-widest font-black text-brand-amber text-center italic drop-shadow-[0_0_10px_rgba(245,158,11,0.3)]">AIP Protocol v4.1 (Sync: Stable)</p>
                            </div>
                        </div>
                </div>
            </aside>

            {/* Main Content Area */}
            <div className="lg:ml-72 flex flex-col min-h-screen">
                {/* Mobile Header */}
                <header className="lg:hidden bg-slate-900/80 backdrop-blur-xl sticky top-0 z-30 px-4 py-3 flex justify-between items-center border-b border-white/5 shadow-sm gap-3">
                    <Link href="/">
                        <img src="/aipcore-logo.svg" alt="AIPCORE" className="h-8 w-auto filter brightness-0 invert" />
                    </Link>
                    <div className="flex items-center gap-2 ml-auto">
                        <CurrencySelector compact />
                        <ConnectButton accountStatus="avatar" chainStatus="icon" showBalance={false} />
                    </div>
                </header>

                {/* Desktop Header */}
                <header className="hidden lg:flex justify-between items-center px-8 py-5 sticky top-0 z-30 bg-background/50 backdrop-blur-xl border-b border-white/5">
                    <h1 className="text-2xl font-black text-white tracking-tight uppercase italic">
                        {navItems.find(item => item.path === pathname)?.name || 'Home'} <span className="text-brand-amber ml-2 opacity-50">/ LOGIC CORE</span>
                    </h1>
                    <div className="flex items-center gap-4">
                        {/* Currency Selector */}
                        <CurrencySelector />
                        <ConnectButton showBalance={{ smallScreen: false, largeScreen: true }} accountStatus="address" />
                    </div>
                </header>

                {/* Main Page Content */}
                <main className="flex-1 p-4 lg:p-8">
                    <div className="max-w-7xl mx-auto">
                        {children}
                    </div>
                </main>
            </div>

            {/* Mobile Bottom Navigation */}
            <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-slate-950/90 backdrop-blur-xl border-t border-white/5 px-2 py-3 z-50 flex justify-around items-center shadow-2xl rounded-t-[2.5rem]">
                {navItems.slice(0, 5).map((item) => {
                    const Icon = item.icon;
                    const isActive = pathname === item.path;
                    
                    const shortName = item.name === 'Dashboard' ? 'Home' : 
                                    item.name === 'Income History' ? 'Income' :
                                    item.name === 'Node Network' ? 'Nodes' :
                                    item.name === 'Node Layers' ? 'Layers' : 'Reward';

                    return (
                        <Link
                            key={item.path}
                            href={item.path}
                            className={`flex flex-col items-center gap-1 group relative px-3 py-1`}
                        >
                            <div className={`p-2 rounded-2xl transition-all duration-300 ${isActive ? 'bg-brand-blue text-white shadow-lg -translate-y-1' : 'text-slate-600'}`}>
                                <Icon className="w-6 h-6" />
                            </div>
                            <span className={`text-[10px] font-black uppercase tracking-widest ${isActive ? 'text-brand-blue' : 'text-slate-500'}`}>
                                {shortName}
                            </span>
                            {isActive && (
                                <div className="absolute -bottom-1 w-1 h-1 bg-brand-blue rounded-full"></div>
                            )}
                        </Link>
                    );
                })}
            </nav>
        </div>
    );
}

export default function DashboardLayout({ children }: { children: ReactNode }) {
    const pathname = usePathname();
    return <DashboardLayoutInner children={children} pathname={pathname} />;
}




