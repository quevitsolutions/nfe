import contractABI from './AIPCore.json';
import rewardPoolABI from './RewardPool.json';
import contractConfig from '../config/contracts.json';

// Contract ABIs
export const AIPCORE_ABI = contractABI.abi;
export const REWARD_POOL_ABI = rewardPoolABI.abi;

// Contract addresses
export const CONTRACT_ADDRESSES = {
    97: contractConfig.contractAddresses.bscTestnet,  // BSC Testnet
    56: contractConfig.contractAddresses.bscMainnet,  // BSC Mainnet
} as const;

// Network configurations
export const SUPPORTED_CHAINS = {
    bscTestnet: {
        id: 97,
        name: 'BSC Testnet',
        network: 'bsc-testnet',
        nativeCurrency: {
            decimals: 18,
            name: 'BNB',
            symbol: 'tBNB',
        },
        rpcUrls: {
            default: { http: [contractConfig.rpcUrls.bscTestnet] },
            public: { http: [contractConfig.rpcUrls.bscTestnet] },
        },
        blockExplorers: {
            etherscan: { name: 'BscScan', url: contractConfig.blockExplorers.bscTestnet },
            default: { name: 'BscScan', url: contractConfig.blockExplorers.bscTestnet },
        },
        testnet: true,
    },
    bscMainnet: {
        id: 56,
        name: 'BSC Mainnet',
        network: 'bsc',
        nativeCurrency: {
            decimals: 18,
            name: 'BNB',
            symbol: 'BNB',
        },
        rpcUrls: {
            default: { http: [contractConfig.rpcUrls.bscMainnet] },
            public: { http: [contractConfig.rpcUrls.bscMainnet] },
        },
        blockExplorers: {
            etherscan: { name: 'BscScan', url: contractConfig.blockExplorers.bscMainnet },
            default: { name: 'BscScan', url: contractConfig.blockExplorers.bscMainnet },
        },
    },
};

// Genesis user ID
export const GENESIS_USER_ID = 36999;

// Income types
export const INCOME_TYPES = {
    1: 'Sponsor',
    2: 'Layer',
    3: 'Matrix',
} as const;

// Level costs (in USD)
export const LEVEL_COSTS_USD = [
    5, 5, 10, 20, 40, 80, 160, 320, 640, 1280,
    2560, 5120, 10240, 20480, 40960, 81920, 163840, 327680
];

// Helper to get contract address for current chain
export function getContractAddress(chainId: number): string {
    return CONTRACT_ADDRESSES[chainId as keyof typeof CONTRACT_ADDRESSES] || CONTRACT_ADDRESSES[97];
}

// Helper to get RewardPool address
export function getRewardPoolAddress(chainId?: number): string {
    if (process.env.NEXT_PUBLIC_REWARD_POOL_ADDRESS) {
        return process.env.NEXT_PUBLIC_REWARD_POOL_ADDRESS;
    }
    
    // Explicit chain mapping based on standard IDs
    if (chainId === 56) return contractConfig.rewardPoolAddresses.bscMainnet;
    if (chainId === 97) return contractConfig.rewardPoolAddresses.bscTestnet;
    
    return contractConfig.rewardPoolAddresses.bscMainnet; // Default to Mainnet if chain undefined
}

// Helper to format BNB
export function formatBNB(wei: bigint | string): string {
    const value = typeof wei === 'string' ? BigInt(wei) : wei;
    return (Number(value) / 1e18).toFixed(6);
}

// Helper to format currency
export function formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
    }).format(amount);
}

// Helper to get income type name
export function getIncomeTypeName(type: number): string {
    return INCOME_TYPES[type as keyof typeof INCOME_TYPES] || 'Unknown';
}
